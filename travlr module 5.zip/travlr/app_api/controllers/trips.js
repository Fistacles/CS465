const mongoose = require('mongoose');
const Trip = require('../models/travlr'); //Register model
const Model = mongoose.model('trips');

// GET: /trips - lists all the trips
// Regardless of outcome, response must include HTML status code
// and Json Message to the requesting client
const tripsList = async(requestAnimationFrame, res) => {
    const q = await Model
        .find({'code' : req.params.tripCode }) // No filter, return all records
        .exec();

        console.log(q);

    if(!q){
        return res
            .status(200)
            .json(q);
    }
};

module.exports = {
    tripsList,
    tripsFindByCode
};